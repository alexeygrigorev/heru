Reviewing the implemented CLI change against the acceptance criteria first, then I’ll rerun the focused and contract verification needed to make an acceptance decision.
The CLI entrypoint and test coverage line up with the requested shape so far. I’m rerunning the targeted CLI suite plus the required litehive smoke coverage now, and I’ll spot-check the actual help output and legacy warning path rather than relying only on prior notes.
The help surface matches the target UX: root help lists engines as subcommands and per-engine help exposes the shared option set. I’m running the required litehive smoke suite now from the dependent repo so the acceptance decision is based on the actual downstream contract, not just heru’s local tests.
The downstream contract run is still in progress. Once that finishes, I’ll submit the reviewer verdict into litehive with the concrete evidence from both heru and litehive verification.
Acceptance evidence is complete: the focused CLI suite passed, the help output matches the new subcommand UX, and the litehive contract smoke run passed against this worktree. I’m recording a `pass` verdict in litehive with the exact verification evidence and what was checked.
`litehive report` failed inside litehive itself because its CLI expects a `files_changed` namespace field that this command path did not populate. I’m checking whether there’s a supported flag or invocation variant that sets that field so the reviewer verdict still gets recorded as required.
`litehive report` has a CLI bug in this environment, so I’m using the underlying report handler with the same payload to persist the reviewer verdict instead of leaving the task unreported. I’ll verify the comment landed after that call.
The fallback call failed because this worktree doesn’t have the litehive package on its import path. I’m switching to the litehive repo, pointing it back at this heru workspace explicitly, and then I’ll confirm the acceptance comment was written to the task record.
The verdict call returned success from litehive. I’m doing one last check to find where that report was persisted in the task artifacts so the acceptance handoff is concrete rather than inferred from the command exit code alone.
The report handler returned success, but this task scaffold currently only has `task.yaml` and `journal.md`, unlike the earlier task layout that included `thread.yaml` and `reports/`. I’m checking whether the accept report landed in a workspace-level state file instead of per-task files before I close this out.
Accepted.

I verified the implemented behavior in [heru/main.py](/home/alexey/git/heru/.litehive/worktrees/T-0002-positional-engine-argument-in-heru-cli-heru/heru/main.py) and [tests/test_heru_cli.py](/home/alexey/git/heru/.litehive/worktrees/T-0002-positional-engine-argument-in-heru-cli-heru/tests/test_heru_cli.py). The CLI now registers engine subcommands from `ENGINE_CHOICES`, exposes the shared `--cwd`, `--model`, `--max-turns`, `--resume`, and `--raw` options on each subcommand, and keeps the legacy `heru <prompt> --engine <engine>` path with a deprecation warning on stderr. Help output also matches the target UX: `heru --help` lists all engines, and `heru <engine> --help` shows the shared option set.

Verification evidence:
- `uv run pytest tests/test_heru_cli.py -q` -> `21 passed`
- `uv run python -c "from heru.main import main; raise SystemExit(main(['--help']))"` -> listed all registered engines as subcommands
- `uv run python -c "from heru.main import main; raise SystemExit(main(['codex','--help']))"` -> showed the shared option set
- `cd ~/git/litehive && PYTHONPATH=/home/alexey/git/heru/.litehive/worktrees/T-0002-positional-engine-argument-in-heru-cli-heru uv run pytest tests/test_runner_workflow.py tests/test_engine_variants_and_timeline.py tests/test_heru_cli.py tests/test_codex_quota.py -q` -> `197 passed`

I also submitted the reviewer `pass` verdict into litehive. The public `litehive report` command currently crashes in this environment due a missing `files_changed` CLI field, so I recorded the same verdict through the underlying litehive report handler as a workaround.

╭───────────────────── Traceback (most recent call last) ──────────────────────╮
│ /home/alexey/git/litehive/litehive/cli/__init__.py:581 in report_command     │
│                                                                              │
│    578 │   ] = None,                                                         │
│    579 │   task_id: Annotated[str | None, typer.Option(help="Task ID. Defaul │
│    580 ) -> int:                                                             │
│ ❱  581 │   return _cmd_report(_ns(command="report", **locals()))             │
│    582                                                                       │
│    583                                                                       │
│    584 @app.command("import-issue", help="Import a single GitHub issue as a  │
│                                                                              │
│ /home/alexey/git/litehive/litehive/cli/report.py:36 in _cmd_report           │
│                                                                              │
│   33 │   │   step=step,                                                      │
│   34 │   │   verdict=normalized_verdict,                                     │
│   35 │   │   message=args.message,                                           │
│ ❱ 36 │   │   files_changed=list(args.files_changed or []),                   │
│   37 │   )                                                                   │
│   38 │   append_thread_comment(root, task, comment)                          │
│   39 │   print(f"task: {task.id}")                                           │
╰──────────────────────────────────────────────────────────────────────────────╯
AttributeError: 'Namespace' object has no attribute 'files_changed'
tail: cannot open '.litehive/tasks/T-0002/task.md' for reading: No such file or directory
warning: `VIRTUAL_ENV=/home/alexey/git/heru/.venv` does not match the project environment path `.venv` and will be ignored; use `--active` to target the active environment instead
Traceback (most recent call last):
  File "<stdin>", line 2, in <module>
ModuleNotFoundError: No module named 'litehive'

[stderr]
Reading additional input from stdin...
